<?php
    
    //******************************************************************************
    // Lab20_Get_Dir.php
    //
   
    function list_directory($dir) {
        $file_list = array();
        $stack[] = $dir;
        
        while ($stack) {
            $current_dir = array_pop($stack);
            if ($dh = opendir($current_dir)) {
                while (($file = readdir($dh)) !== false) {
                    if ($file !== '.' AND $file !== '..') {
                        $current_file = "{$current_dir}/{$file}";
                        $extension = strtolower(substr($file, -3));
                            if (is_file($current_file)) {
                                if ($extension == "jpg" ||
                                    $extension== "png" ||
                                    $extension == "gif"||
                                    $extension == "tif") {
                                         $file_list[] = "{$current_dir}/{$file}";
                                }
                         } elseif (is_dir($current_file)) {
                             $stack[] = $current_file;
                                if ($extension == "jpg" ||
                                    $extension== "png" ||
                                    $extension == "gif"||
                                    $extension == "tif") {
                                         $file_list[] = "{$current_dir}/{$file}";
                                 }
                            }               
                    }
             }
         }
        }
        return $file_list;
    }
    echo("Get the image files from the directory:<br>");
    $allFiles =list_directory('../htdocs/images');
    print_r($allFiles);
    echo("<hr>");
    
    echo("Convert the data using JSON_Encode() function:<br>");
    $allFiles_json = json_encode($allFiles);
    echo($allFiles_json);
    echo("<hr>");
?> 