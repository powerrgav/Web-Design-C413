<html>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    
    <?php
        include_once("Lab20_Get_Dir.php");
    ?>

    <head>
        <script type="text/javascript">
            //---------------------------------------------------------------
            // Global Variables
            //---------------------------------------------------------------
            var nextSlide = 0; // Keeps the sequence number for which image is being displayed
            var theFiles; // Keeps an array of file names corresponding to theSlideShowFiles
            var myTimer;
            //-------------------------------------------------------------
            //
            //
            function displaySlideShow(theSlideShowFiles)
            {
                theFiles = theSlideShowFiles; // Keep this in a global variable.
                clearTimeout(myTimer);

                if(nextSlide < theFiles.length){
                    document.getElementById("slide").innerHTML = "<img id='SlideFrame' src='" +
                    theFiles[nextSlide] +
                    "' height= 240 title='"+
                    theFiles[nextSlide] +"'> <br>";
                    nextSlide=nextSlide+1;
                    myTimer = setTimeout("displaySlideShow(theFiles)", 4000);
                }
                else { // start from the beginning of the array
                    nextSlide = 0;
                    setTimeout("displaySlideShow(theFiles)", 100);
                }
            }
        </script>
    </head>

    <body>
        <div id="SlideShowPanel" title="...Slide show">
            <p> This text will appear above the slide.... </p>

            <span id="slide" >

            </span>

            <p> This text will appear below the slide.... </p>
        </div>

        <script type="text/javascript">
            /*var theSlideShowFiles= Array();
            theSlideShowFiles[0] = "../images/JS_slides/Slide1.JPG";
            theSlideShowFiles[1] = "../images/JS_slides/Slide2.JPG";
            theSlideShowFiles[2] = "../images/JS_slides/Slide3.JPG";
            alert(theSlideShowFiles);
            displaySlideShow(theSlideShowFiles);
            */
           // Use JSON to get the directory information for the slide show
            // theFiles is an array of image file names.
            var theSlideShowFiles = JSON.parse('<?php echo $allFiles_json ?>');
            displaySlideShow(theSlideShowFiles);
        </script>

    </body>
</html>