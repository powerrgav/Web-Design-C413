<?php
    // AJAX
    // AJAX = Asynchronous JavaScript and XML
    // AJAX allows web pages to be updated asynchronously by exchanging
    // small amounts of data with the server behind the scenes. This
    // means that it is possible to update parts of a web page,
    // without reloading the whole page.

    include_once("Lab22_Club_Membership_Class.php");


    $myClub = new Club("localhost","Lab22User","Pass123Word", "lab22");


    // the "email" is sent to this script via the GET super global variable
    //
    $email = $_GET['email'];
    $picture = $_GET['picture'];

    echo("<H3> Member Interests are Extracted Via AJAX</H3>");
    //echo($email . "<br />");
    $Interests = $myClub->Get_Members_Interests_From_DB($email);
    
    for($j =0; $j < sizeof($Interests); $j++)
        echo("<li>" . $Interests[$j]['InterestDescription'] . "</li>");

    echo("<img src='$picture' height='240'>");

?>