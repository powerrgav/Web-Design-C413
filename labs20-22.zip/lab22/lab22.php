<!DOCTYPE html>
<html>
    <head>
        <!--
        Lab22.php
        Gavin Power
        CSCI-C490 Client Server Web Programming
        Using AJAX, MySQL and PHP
        -->
        <title>IUSB Informatics Student Club (MySQL and Classes)</title>
        <meta charset="UTF-8">
        <meta name="Keywords" content="AJAX, PHP, MySQL, CSS, JavaScript, Arrays, input tag for reading the directory, event handling, DIV,
        IMG, Web Programming" >
        
        <!-- ----------- STYLE ---------------->
        <div id="myStyles">
            <link rel="stylesheet" type="text/css" href="Lab22_Styles.css" >
        </div>
        <!-- ------- Java Scripts ------------->
        <script>
            function displayInterests(email, picture)
            {
                var xmlhttp;
                if (window.XMLHttpRequest)
                { // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp=new XMLHttpRequest();
                }
                else
                { // code for IE6, IE5
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }

                // When a request to a server is sent, we want to perform some
                // actions based on the response.
                // The onreadystatechange event is triggered every time the
                // readyState changes. The readyState property holds the
                // status of the XMLHttpRequest.

                xmlhttp.onreadystatechange=function()
                {
                    if (xmlhttp.readyState==4 && xmlhttp.status==200)
                    {
                    document.getElementById("BodyContent").innerHTML=xmlhttp.responseText;
                    }
                }

                //alert(email);
                //alert(picture);
                xmlhttp.open("GET","Lab22_Get_Membership_Info.php?email="+email+"&picture="+picture,true);
                xmlhttp.send();

            }
        </script>
    </head>

    <body style="margin: 1cm;">
       
        <div id="container" style="width:900px; ">
        <!-- ------------------ Header --------------------------- -->
        <div class="horizontalbar" id="bar1" > </div>
        <div class="header">Informatics Student Club 3.0 (AJAX, MySQL)</div>
        <div class="horizontalbar" id="bar2" > </div>

        <!-- ------------------ Left Navigation ------------------------ -->
        <div id="LeftNav";>
        <?php
            include_once("Lab22_Club_Membership_Class.php");

            echo("<H3> CLub Members </H3>");
            $myClub = new Club("localhost","Lab22User","Pass123Word", "lab22");
            $members = $myClub->Get_Members_From_DB();
            for ($i = 0 ; $i < sizeof($members); $i++)
            {
                $functionCall = "displayInterests('" . $members[$i]['Email'] .

                                                     "', '" .

                                                    $members[$i]['Picture'] . "');" ;
            //echo $functionCall;
            // Create an “onmousover” event handler for each member.
            echo("<p onmouseover=\" $functionCall \">" .
                                    $members[$i]['FirstName'] .
                                     " " .
                                     $members[$i]['LastName'] .
                                    "</p>");
            }
        ?>
        </div>
        <!-- ------------------ Body ------------------------ -->
        <div id="BodyContent"; >
        </div>
        <!-- -------------------------Copyright area ---------------------------- -->
        <div id="copyright" >
            <h3> &#169 Copyright 2024 by C413 Web Programming </h3>

        </div>
        </div>
    </body>
</html>