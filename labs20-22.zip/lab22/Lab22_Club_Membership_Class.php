<?php
    class Club {
        //Private Data
        private $HostName; // typically "localhost"
        private $UserID;
        private $Password;
        private $DBName;
        private $Con; // MySQL Connection
        //-------------------------------------------------
        //-------------------------------------------------
        // Public Methods
        //-------------------------------------------------
        //-------------------------------------------------
        // Constructor
        public function __construct($host = NULL, $uid = NULL,
        $pw = NULL, $db = NULL)
        {
            //echo("The class constructor is being called... <br />");
            $this->HostName = $host;
            $this->UserID = $uid;
            $this->Password = $pw;
            $this->DBName = $db;

            // Connect to Database
            $this->Con = mysqli_connect($host, $uid, $pw, $db);
            if (mysqli_connect_errno())
            {
                echo "Failed to connect to MySQL: " . mysqli_connect_error();
            }
        }
        //-------------------------------------------------
        // Destructor
        public function __destruct()
        {
        //echo("The class destructor is being called... <br />");
        // Close connection
            mysqli_close($this->Con);
        }
        //-------------------------------------------------
        public function DisplayMembers()
        {
        }
        //-------------------------------------------------
        function DisplayAbout()
        {
        }
        //-------------------------------------------------
        function DisplayRegistrationForm()
        {
        }
        //-------------------------------------------------
        function ProcessRegistrationForm()
        {
        }
        //-------------------------------------------------
        //-------------------------------------------------
        // Private Methods
        //-------------------------------------------------
        //-------------------------------------------------
        public function Get_Members_From_DB()
        {
            $sql = "SELECT
                        member.Email,
                        member.FirstName,
                        member.LastName,
                        member.Gender,
                        member.MemberSince,
                        member.Picture
                    FROM
                        member
                        ";
            $result = mysqli_query($this->Con,$sql);
        // print_r($result);
            $arrayResult = array();
            while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
                $arrayResult[] = $row;
            //print_r($row);
            //echo "<br />";
            }
            return($arrayResult);
        }
        //-------------------------------------------------
        public function Get_Members_Interests_From_DB($MemberEmail)
        {
            $sql = "SELECT
                        interest_type.InterestDescription
                    FROM
                        member, member_interests, interest_type
                    WHERE
                         member.Email = '$MemberEmail'
                    AND
                        member.Email = member_interests.Email
                     AND
                        member_interests.InterestID = interest_type.InterestID";

            $result = mysqli_query($this->Con,$sql);
            $arrayResult = array();
            while($row = mysqli_fetch_array($result)) {
                 $arrayResult[] = $row;
                 //print_r($row);
                //echo "<br />";
            }
            return($arrayResult);
        }
        //-------------------------------------------------
        private function Get_Interests_Types_From_DB()
        {
        }
    }
?>