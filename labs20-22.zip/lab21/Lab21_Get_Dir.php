<?php
    //******************************************************************************
    // Lab21_Get_Dir.php
    //
    // When this file is called by the Lab21.php, the dir_path is sent to it
    // via the $_GET super global variable.
    //
    // Below, we test for the existence of the global variable and
    // then proceed to use it to call the list_directory() function
    // passing it the dir_path as parameter.
    // Get the image files from the directory
    if(isset($_GET['dir_path'])) {
        $dir_path = $_GET['dir_path'];
        $allFiles =list_directory($dir_path); // '../images');
        // Convert the data using JSON_Encode() function
        $allFiles_json = json_encode($allFiles);
        echo($allFiles_json);
    }
    else
     echo("directory path not specified");



    //---------------------------------------------------------------------
    // Get the list of files in the directory and return them.
    //
    function list_directory($dir) {
        $file_list = array();
        $stack[] = $dir;
        while ($stack) {
            $current_dir = array_pop($stack);
            if ($dh = opendir($current_dir)) {
                while (($file = readdir($dh)) !== false) {
                    if ($file !== '.' AND $file !== '..') {
                        $current_file = "{$current_dir}/{$file}";
                        $extension = strtolower(substr($file, -3));
                            if (is_file($current_file)) {
                                if ($extension == "jpg" ||
                                    $extension== "png" ||
                                    $extension == "gif"||
                                    $extension == "tif") {
                                        $file_list[] = "{$current_dir}/{$file}";
                                }
                            } elseif (is_dir($current_file)) {
                                $stack[] = $current_file;
                                if ($extension == "jpg" ||
                                $extension== "png" ||
                                $extension == "gif"||
                                $extension == "tif") {
                                     $file_list[] = "{$current_dir}/{$file}";
                                }
                            }
                    }               
                }
              }
            }
    return $file_list;
    }
?> 