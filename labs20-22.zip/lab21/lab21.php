<html>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <!--
        File: lab21.php
        Description:
        Understanding JSON (JavaScript Object Notation)
        Passing PHP data to Javascript using JSON.
        Understanding JSON (JavaScript Object Notation)
        JSON is a lightweight data-interchange format, and somewhat similar to XML.
        The basic idea is to:
        1) get PHP to produce a string (html, etc...) and put it in a variable.
        2) Use the json_encode() function to encode the variable:
        $phpVariable_json_encoded = json_encode($phpVariable);
        3) In javascript use JSON.parse() function to extract the php variable and put it in a javascript variable
        4) Put the javascript variable where you want
        -->
<head>
    <script type="text/javascript">
    //---------------------------------------------------------------
    // Global Variables
    //---------------------------------------------------------------
    var nextSlide = 0; // Keeps the sequence number for which image is being displayed
    var theFiles; // Keeps an array of file names corresponding to theSlideShowFiles
    var myTimer; // The timer is used to control the interval of time for the slide show
    var JSON_String = "------> Empty <-------"; // Will hold the JSON string returned from the call to PHP script
    //-------------------------------------------------------------
    //
    //
    function displaySlideShow(theSlideShowFiles)
    {
        theFiles = theSlideShowFiles; // Keep this in a global variable.
        clearTimeout(myTimer);
        if(nextSlide < theFiles.length){
            document.getElementById("slide").innerHTML = "<img id='SlideFrame' src='" +
                                                                    theFiles[nextSlide] +
                                                                "' height= 240 title='"+
                                                            theFiles[nextSlide] +"'> <br>";
            nextSlide=nextSlide+1;
            myTimer = setTimeout("displaySlideShow(theFiles)", 4000);
        }
        else {
            nextSlide = 0;
            setTimeout("displaySlideShow(theFiles)", 100);
        }
    }
    // ---------------------------------------------------------------
    function getFileNames(dir_path) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                JSON_String = this.responseText;
            }
        }
 // Try changing the last parameter to false = synchronous
 // then see the difference when you alert() the result.
 xmlhttp.open("GET", "Lab21_Get_Dir.php?dir_path="+dir_path, false);
 xmlhttp.send();
    }
    </script>
</head>

<body>
    <div id="SlideShowPanel" title="...Slide show">
        <p> This text will appear above the slide.... </p>
        
        <span id="slide" >
        </span>
        <p> This text will appear below the slide.... </p>
    </div>

<script type= "text/javascript">
    alert("Starting the process");

    getFileNames('../images');

    alert("JSON String before AJAX has had the chance to return all the data " + JSON_String);
    var theSlideShowFiles = JSON.parse(JSON_String);

    alert("JSON String after AJAX has had the chance to return the data: " + JSON_String);
    displaySlideShow(theSlideShowFiles);
</script>

</body>
</html>