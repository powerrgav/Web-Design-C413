<?php
 
if(isset($_GET["partialEmail"])) {
    if ($_GET["partialEmail"] == "h")
        echo("hhakimza@iusb.edu ; hamilton@iusb.edu ; hanson@iusb.edu");
    else if ($_GET["partialEmail"] == "hh")
        echo("hhakimza@iusb.edu");
    else if ($_GET["partialEmail"] == "ha")
     echo("hamilton@iusb.edu ; hanson@iusb.edu");
    else if ($_GET["partialEmail"] == "han")
        echo("hanson@iusb.edu");
    else if ($_GET["partialEmail"] == "hha")
        echo("hhakimza@iusb.edu");
    else if ($_GET["partialEmail"] == "ham")
        echo("hamilton@iusb.edu");
    else if ($_GET["partialEmail"] == "hhak")
        echo("hhakimza@iusb.edu");
    else if ($_GET["partialEmail"] == "hhan")
        echo("hhanson@iusb.edu");
    else if ($_GET["partialEmail"] == "a")
        echo("amy@iu.edu");
    else if ($_GET["partialEmail"] == "g")
        echo("gavpower@iu.edu");
    else if ($_GET["partialEmail"] == "ga")
        echo("gavpower@iu.edu");
    else if ($_GET["partialEmail"] == "gav")
        echo("gavpower@iu.edu");
    else
        echo("No match, Email not found...");
 }
?>