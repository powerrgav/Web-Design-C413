<?php
// Lab 18
    class CoursesTaken {

     //Private Data

    private $HostName;
    private $UserID;
    private $Password;
    private $DBName;

    private $Con; // MySQL Connection

    //----------------------------------------------
    // Constructor
    // Instantiating the object with proper
    // host, user, password and database credentials
    public function __construct($host = NULL, $uid = NULL, $pw = NULL, $db = NULL)
    {
        echo("The class constructor is being called... <br />");
        $this->HostName = $host;
        $this->UserID = $uid;
        $this->Password = $pw;
        $this->DBName = $db;

        // Connect to Database
        $this->Con = mysqli_connect($host, $uid, $pw, $db);
        if (mysqli_connect_errno())
        {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }
        else
            echo "Successful Connection to MySQL <br />";
    }

     //-------------------------------------------------
    // Destructor
    // Close the connection
     public function __destruct()
    {
        echo("The class destructor is being called... <br />");
        // Close connection
        mysqli_close($this->Con);
    }

    // To Add a record to the classes_taken table
    public function Add_Class($course, $credit, $semester, $year, $grade)
    {
        // Note that some of the values below are quoted and some are not.
        // This is the difference between numeric and string fields
        $sql = "INSERT INTO
                     classes_taken (`Class`, `Credits`, `Semester`, `Year`, `Grade`)
                VALUES
                    ('$course', $credit, '$semester', $year, '$grade');
                ";
        $result = mysqli_query($this->Con,$sql);
        if ($result == true) {
            echo "Successful Insert<br />";
        }
        else {
            echo "Error Inserting class" . mysqli_error($this->Con) ." <br />";
        } 
    }
    // Display all the classes taken up to this point
    public function Print_Transcript()
    {
        $sql = "SELECT
                     Class, Credits, Semester, Year, Grade
                FROM
                    classes_taken
                ";
       
        $result = mysqli_query($this->Con,$sql);

        $arrayResult = array();

        echo("----------------Start Transcript----------------<br />");
        while($row = mysqli_fetch_array($result)) {
            $arrayResult[] = $row; // Store the record to be returned
            echo($row['Class'] . " " .
                $row['Credits'] . " " .
                $row['Semester'] . " " .
                $row['Year'] . " " .
                $row['Grade']
                );
            echo "<br />";
        }
        echo("----------------End Transcript----------------<br />");
        return($arrayResult);
    }

    // Display the total number of credits taken up to this point
    public function Total_Credits()
    {
        $sql = "SELECT
                     sum(Credits) AS Total_Credits
                 FROM
                    classes_taken
                 ";
        $result = mysqli_query($this->Con,$sql);

        $arrayResult = array();

        echo("---------------- Start Total Credits ----------------<br />");
        while($row = mysqli_fetch_array($result)) {
            $arrayResult[] = $row; // Store the record to be returned
            echo("Total credits completed = " . $row['Total_Credits'] );
            echo "<br />";
        }
        echo("---------------- End Total Credits ----------------<br />");
        return($arrayResult); 
    }
}
?>

 <?php
    // Testing the class
    $MyCourses = new CoursesTaken("localhost", "Lab18User", "Pass123Word", "Lab18");
    $MyCourses->Print_Transcript();
    $MyCourses->Total_Credits();

    $MyCourses->Add_Class("CSCI-C490", 3, "Summer", 2017, "A");
    $MyCourses->Print_Transcript();
    $MyCourses->Total_Credits(); 
?>